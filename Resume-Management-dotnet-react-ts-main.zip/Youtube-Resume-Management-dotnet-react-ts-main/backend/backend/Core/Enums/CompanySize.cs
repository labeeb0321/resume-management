﻿namespace backend.Core.Enums
{
    public enum CompanySize
    {
        Small,
        Medium,
        Large
    }
}
