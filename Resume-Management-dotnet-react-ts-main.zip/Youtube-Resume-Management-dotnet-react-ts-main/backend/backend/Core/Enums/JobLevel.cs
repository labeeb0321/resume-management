﻿namespace backend.Core.Enums
{
    public enum JobLevel
    {
        Intern,
        Junior,
        MidLevel,
        Senior,
        TeamLead,
        Cto,
        Architect
    }
}
